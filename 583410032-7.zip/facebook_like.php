<?php
$url="http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>
<iframe allowTransparency='true' src='https://www.facebook.com/plugins/like.php?href=<?php echo $url;?>&layout=box_count&;show_faces=false&width=100&action=like&font=arial&colorscheme=light' frameborder='0' scrolling='no' style='border:none; overflow:hidden; width:55px; height:62px;'>
</iframe>